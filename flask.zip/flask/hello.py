from flask import Flask

"""here we create app variable and initialize it with flask instance
 __name__ is special variable in python it is name of module 
if we run it python then __name__ = __main__
It is where flask look for template and static file
here we instantiate flask variable
"""
app = Flask(__name__)  #here we configure flask object

"""
route is used for go to different pages i.e go to about page , home page is done in flask using route
it is created using decorator
/ it is stand for root page of our website i.e homepage
"""
@app.route('/') #it is decorator and it indicate that following function run under this index, it display follwoing under this route
def hello():
    return "<h1>Hello, World!</h1>"

"""
to run use
 (flask) icpl12900@icpl12900-OptiPlex-5050:~/Flask_blog$ export FLASK_APP=hello.py
(flask) icpl12900@icpl12900-OptiPlex-5050:~/Flask_blog$ flask run
when we make changes in file after that we have restrat server by using ctrl+c
but if we don't want to restart server again then use debug mode by "export FLASK_DEBUG=1"
and we can set this enviromental variable in file of python also then directly run file using python filename.py
for this use following code
"""
if __name__ == '__main__':
	app.run(debug=True)